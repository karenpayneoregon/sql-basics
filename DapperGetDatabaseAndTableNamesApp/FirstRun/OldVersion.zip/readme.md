﻿# About

Example to get a database names and their table names and writes them to a simple text file.

As presented the code reads the connection string from appsettings.json so if there is a need to work against more than one server the code needs to change to work for more than one server

There is starter code to get view names for a database but not implemented.

- Written in NET8
- Uses [Dapper](https://www.nuget.org/packages/Dapper) NuGet package
