﻿using System.Text;
using DapperGetDatabaseAndTableNamesApp.Classes;

namespace DapperGetDatabaseAndTableNamesApp;

internal partial class Program
{
    static void Main()
    {



        var list = DataOperations.ReadDataContainers();

        List<IGrouping<string, DataContainer>> grouped = 
            list.GroupBy(x => x.DatabaseName).ToList();

        WriteToFile(grouped);

        foreach (var groupItem in grouped.Where(groupItem => !AvoidDatabaseNameList.Contains(groupItem.Key)))
        {
            Console.WriteLine(groupItem.Key);
            foreach (var item in groupItem)
            {
                if (AvoidTableNameList.Contains(item.TableName))
                {
                    continue;
                }
                Console.WriteLine($"     {item.SchemaName}.{item.TableName}");
                var columns = DataOperations.ReadColumnDetailsForTable(".\\SQLEXPRESS", groupItem.Key, item.TableName);
                foreach (var column in columns)
                {
                    Console.WriteLine($"          {column.Position} {column.ColumnName}");
                }
            }
        }

        Console.ReadLine();
    }
    private static List<string> AvoidDatabaseNameList => new() { "master", "msdb" };
    private static List<string> AvoidTableNameList => new() { "sysdiagrams" };
    private static void WriteToFile(List<IGrouping<string, DataContainer>> grouped)
    {

        StringBuilder builder = new();

        foreach (var groupItem in grouped.Where(groupItem => !AvoidDatabaseNameList.Contains(groupItem.Key)))
        {
            builder.AppendLine(groupItem.Key);
            foreach (var item in groupItem)
            {
                if (AvoidTableNameList.Contains(item.TableName))
                {
                    continue;
                }
                builder.AppendLine($"     {item.SchemaName}.{item.TableName}");
            }
        }
        
        File.WriteAllText("DatabaseAndTableNames.txt", builder.ToString());
    }
}