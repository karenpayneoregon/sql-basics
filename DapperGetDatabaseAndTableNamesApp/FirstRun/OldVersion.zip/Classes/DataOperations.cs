﻿using Dapper;
using Microsoft.Data.SqlClient;
using static ConfigurationLibrary.Classes.ConfigurationHelper;

namespace DapperGetDatabaseAndTableNamesApp.Classes;
internal class DataOperations
{
    public static List<DataContainer> ReadDataContainers()
    {

        using var connection = new SqlConnection(ConnectionString());
        connection.Open();
        return connection.Query<DataContainer>(SqlStatements.GetDatabasesStatement).AsList();

    }

    public static List<ViewContainer> ReadViews()
    {

        using var connection = new SqlConnection(ConnectionString());
        connection.Open();
        return connection.Query<ViewContainer>(SqlStatements.GetViewsStatement).AsList();

    }

    public static List<ColumnContainer> ReadColumnDetailsForTable(string dataSource, string catalog, string tableName)
    {

        SqlConnectionStringBuilder builder = new(ConnectionString())
        {
            DataSource = dataSource,
            InitialCatalog = catalog
        };

        using var connection = new SqlConnection(builder.ConnectionString);
        return connection.Query<ColumnContainer>(SqlStatements.GetColumnDetailsForTable,
            new { TableName = tableName }).AsList();
    }
}
