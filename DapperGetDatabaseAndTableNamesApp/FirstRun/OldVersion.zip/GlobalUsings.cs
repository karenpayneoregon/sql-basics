// Global using directives

global using ConsoleHelperLibrary.Classes;
global using Spectre.Console;